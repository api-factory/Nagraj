package com.wipro.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.wipro.model.Message;
import com.wipro.model.Person;
import com.wipro.service.RestService;


@org.springframework.web.bind.annotation.RestController
@RequestMapping("/persons")
public class RestController {
	
	@Autowired
	private RestService restService;

	@RequestMapping(value="/getPersonDetails",method=RequestMethod.GET,produces="application/json")
	public List<Person> getPersonDetails(@RequestHeader("Accept") String accept){
		
		System.out.println("accept=========="+accept);
		
		return restService.getPersonDetails();
	}
	
	@RequestMapping(value="/getPersonDetail/{id}",method=RequestMethod.GET,produces="application/json")
	public Person getPersonDetail(@RequestHeader("Accept") String accept,@PathVariable("id")String id,
			             @RequestParam(value="name",defaultValue = "10")String name){
		
		System.out.println("accept=========="+accept+"id===="+id+" name====="+name);
		
		return restService.getPersonDetail();
	}
	
	@RequestMapping(value="createPersonDetails",method=RequestMethod.POST,produces="application/json",consumes="application/json")
	public Message createPersonDetail(@RequestHeader("Accept") String accept,@RequestHeader("Content-Type")String contentType,@RequestBody List<Person> personDetails){
		
		System.out.println("accept=========="+accept+"contentType===="+contentType);
		
		return restService.createPersonDetail(personDetails);
	}

}
