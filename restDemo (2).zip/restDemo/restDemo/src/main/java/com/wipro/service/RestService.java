package com.wipro.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.wipro.model.Message;
import com.wipro.model.Person;

@Service("restService")
public class RestService {

	
public List<Person> getPersonDetails(){
		
		List<Person> personDetails = new ArrayList<Person>();
		Person person = new Person();
		
		person.setAge(22);
		person.setFirstName("chandra");
		person.setLastName("singh");
		person.setId("222");
		
		personDetails.add(person);
		
		 person = new Person();
		 
		 person.setAge(24);
		 person.setFirstName("chandra");
		 person.setLastName("singh");
		 person.setId("5555");
		
		 personDetails.add(person);
		 
		return personDetails;
	}
	
public Person getPersonDetail(){
		
		
		Person person = new Person();
		
		person.setAge(22);
		person.setFirstName("chandra");
		person.setLastName("singh");
		person.setId("222");
		 
		return person;
	}

public Message  createPersonDetail(List<Person> personDetails){
	
	Message message = new Message();
	
	System.out.println(personDetails.get(0).getFirstName());
	
	message.setMessage("person details created successfuly");
	 
	return message;
}
}
